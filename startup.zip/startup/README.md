# Дуже довгий сайт! (StartUp)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/NWmMbyB](https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/NWmMbyB).

